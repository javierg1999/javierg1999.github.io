export const PROJECTS = [
  {
    id: 1,
    title: "Project Management Dashboard",
    description: "A modern project management tool built with React",
    category: "Web App",
    image: "https://images.unsplash.com/photo-1508873535684-277a3cbcc4e8",
    links: {
      demo: "#",
      github: "#"
    }
  },
  {
    id: 2,
    title: "Analytics Platform",
    description: "Real-time analytics dashboard with data visualization",
    category: "Data",
    image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40",
    links: {
      demo: "#",
      github: "#"
    }
  },
  {
    id: 3, 
    title: "E-commerce Solution",
    description: "Full-stack e-commerce platform with payment integration",
    category: "Web App",
    image: "https://images.unsplash.com/photo-1510759395231-72b17d622279",
    links: {
      demo: "#", 
      github: "#"
    }
  },
  {
    id: 4,
    title: "Mobile App UI Kit",
    description: "Modern mobile UI components built with React Native",
    category: "Mobile",
    image: "https://images.unsplash.com/photo-1660592868727-858d28c3ba52",
    links: {
      demo: "#",
      github: "#"  
    }
  },
  {
    id: 5,
    title: "AI Image Generator",
    description: "AI-powered image generation tool using stable diffusion",
    category: "AI/ML",
    image: "https://images.unsplash.com/photo-1685478237595-f452cb125f27",
    links: {
      demo: "#",
      github: "#"
    }
  },
  {
    id: 6,
    title: "Cloud Infrastructure",
    description: "Scalable cloud infrastructure with Terraform and AWS",
    category: "DevOps",
    image: "https://images.unsplash.com/photo-1679409759768-bea306439ab8",
    links: {
      demo: "#",
      github: "#"
    }
  }
];

export const PROJECT_CATEGORIES = ["All", "Web App", "Mobile", "Data", "AI/ML", "DevOps"];

export const SKILLS = [
  "JavaScript/TypeScript",
  "React/Next.js",
  "Node.js",
  "Python",
  "AWS",
  "Docker",
  "PostgreSQL",
  "GraphQL",
  "TailwindCSS",
  "Git"
];

export const EXPERIENCE = [
  {
    title: "Senior Software Engineer",
    company: "Tech Corp",
    period: "2020 - Present",
    description: "Led development of enterprise applications using React and Node.js"
  },
  {
    title: "Software Engineer",
    company: "StartupCo",
    period: "2018 - 2020", 
    description: "Full-stack development with Python and React"
  },
  {
    title: "Junior Developer",
    company: "DevAgency",
    period: "2016 - 2018",
    description: "Frontend development with JavaScript and React"
  }
];

export const EDUCATION = [
  {
    degree: "M.S. Computer Science",
    school: "Tech University",
    year: "2016"
  },
  {
    degree: "B.S. Computer Science",
    school: "State University",
    year: "2014"
  }
];
