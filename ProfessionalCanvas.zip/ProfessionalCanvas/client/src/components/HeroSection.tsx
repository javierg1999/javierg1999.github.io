import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowDown, Github, Linkedin, Mail } from "lucide-react";

export default function HeroSection() {
  return (
    <section id="hero" className="min-h-screen relative flex items-center overflow-hidden bg-muted/30">
      <div className="retro-grid" />

      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background/80 z-10" />

      <div className="container mx-auto px-6 relative z-20">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6 neon-text">
              Hi, I'm{" "}
              <span className="vaporwave-gradient">
                John Doe
              </span>
            </h1>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h2 className="text-2xl md:text-3xl text-cyan-300 mb-8">
              Full Stack Developer specializing in building exceptional digital experiences
            </h2>
          </motion.div>

          <motion.div 
            className="flex flex-wrap gap-4 mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Button size="lg" className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600">
              <Mail className="mr-2 h-4 w-4" /> Contact Me
            </Button>
            <Button size="lg" variant="outline" className="border-pink-500 text-pink-500 hover:bg-pink-500/10">
              Download Resume
            </Button>
          </motion.div>

          <motion.div
            className="flex gap-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            <a href="#" className="text-cyan-300 hover:text-pink-500 transition-colors">
              <Github className="h-6 w-6" />
            </a>
            <a href="#" className="text-cyan-300 hover:text-pink-500 transition-colors">
              <Linkedin className="h-6 w-6" />
            </a>
            <a href="#" className="text-cyan-300 hover:text-pink-500 transition-colors">
              <Mail className="h-6 w-6" />
            </a>
          </motion.div>
        </div>
      </div>

      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ 
          duration: 0.5, 
          delay: 0.8,
          repeat: Infinity,
          repeatType: "reverse"
        }}
      >
        <ArrowDown className="h-6 w-6 text-pink-500" />
      </motion.div>
    </section>
  );
}