import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { SKILLS } from "@/lib/constants";

export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-muted/5">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="grid md:grid-cols-2 gap-12 items-center"
        >
          <div className="retro-border p-4">
            <img
              src="https://images.unsplash.com/photo-1507679799987-c73779587ccf"
              alt="Profile"
              className="rounded-2xl"
            />
          </div>

          <div>
            <h2 className="text-3xl font-bold mb-6 neon-text">About Me</h2>

            <div className="space-y-4 text-cyan-300 mb-8">
              <p>
                I'm a passionate Full Stack Developer with over 5 years of experience
                building web applications. I specialize in JavaScript technologies
                across the stack and have a strong foundation in software architecture
                and cloud services.
              </p>
              <p>
                When I'm not coding, you can find me contributing to open source
                projects, writing technical blog posts, or exploring new technologies.
              </p>
            </div>

            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4 text-pink-500">Skills</h3>
              <div className="flex flex-wrap gap-2">
                {SKILLS.map((skill) => (
                  <motion.div
                    key={skill}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3 }}
                    viewport={{ once: true }}
                  >
                    <Card className="px-4 py-2 retro-border bg-transparent text-cyan-300">
                      {skill}
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}